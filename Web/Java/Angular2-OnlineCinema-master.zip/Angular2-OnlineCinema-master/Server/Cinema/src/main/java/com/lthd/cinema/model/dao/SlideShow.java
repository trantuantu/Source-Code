package com.lthd.cinema.model.dao;

public class SlideShow {
	public String url;
	public String img;
	
	public SlideShow(String url, String img) {
		super();
		this.url = url;
		this.img = img;
	}
}
