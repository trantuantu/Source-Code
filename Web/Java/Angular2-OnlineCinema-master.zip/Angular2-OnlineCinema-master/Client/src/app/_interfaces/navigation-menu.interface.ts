export interface NavigationMenu {
  title: string;
  link: string;
  active: boolean;
}

