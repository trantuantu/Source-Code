export interface TabMenu {
  title: string;
  active: boolean;
}
