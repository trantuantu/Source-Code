export class SlideShow {

  constructor(public url: string,
              public image: string) {
  }
}
