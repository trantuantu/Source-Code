export class Film {
  constructor(public id: string,
              public name: string,
              public genre: string,
              public duration: string,
              public release: string,
              public img: string,
              public trailer: string) {
  }
}
