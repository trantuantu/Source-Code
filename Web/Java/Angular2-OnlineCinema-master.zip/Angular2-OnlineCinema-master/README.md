# OnlineCinema
Angular2 - Online Cinema
Link demo: https://www.youtube.com/playlist?list=PLfoLrNwHcKKB-vYaLoGmAruhv_OMsxmkw
